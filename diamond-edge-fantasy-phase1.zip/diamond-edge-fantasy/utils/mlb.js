export async function getTeams(){
 const res = await fetch('https://statsapi.mlb.com/api/v1/teams');
 return res.json();
}