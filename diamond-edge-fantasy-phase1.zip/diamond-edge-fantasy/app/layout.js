import './globals.css';
export const metadata = { title:'Diamond Edge Fantasy' };
export default function RootLayout({children}) {
 return <html><body>{children}</body></html>;
}