import Navbar from '../components/Navbar';
export default function Home(){
return (
<div>
<Navbar />
<section className="hero">
<h1>Diamond Edge Fantasy</h1>
<h2>Win Your Fantasy League With Smarter Baseball Analytics</h2>
<p>Advanced MLB analytics built around YOUR league.</p>
<button>Start Free</button>
</section>
<section className="cards">
<div className="card">League Analytics</div>
<div className="card">Player Database</div>
<div className="card">Trade Insights</div>
</section>
</div>
)}