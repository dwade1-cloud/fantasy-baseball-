# Diamond Edge Fantasy

Next.js fantasy baseball analytics MVP.

## Run
npm install
npm run dev

Features:
- Home page
- Apple + Sports UI
- MLB API ready
- Dashboard structure
- League wizard placeholder
