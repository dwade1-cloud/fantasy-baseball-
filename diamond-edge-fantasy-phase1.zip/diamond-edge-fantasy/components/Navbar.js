export default function Navbar(){
return(
<nav>
<div>Diamond Edge Fantasy</div>
<div>Home | Dashboard | Players | Pricing</div>
</nav>
)}