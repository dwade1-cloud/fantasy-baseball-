
export default function Pricing(){
return(
<div style={{padding:'40px'}}>
<h1>Pricing</h1>
<div style={{display:'flex',gap:'20px'}}>
<div>Free</div><div>Pro</div><div>Elite</div>
</div>
</div>
)}
