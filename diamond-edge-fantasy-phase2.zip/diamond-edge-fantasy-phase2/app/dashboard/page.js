
'use client'
export default function Dashboard(){
return(
<div style={{padding:'40px'}}>
<h1>Team Dashboard</h1>
<div style={{display:'flex',gap:'20px',flexWrap:'wrap'}}>
<div style={{background:'rgba(255,255,255,.05)',padding:'20px',borderRadius:'20px'}}>Team Strengths</div>
<div style={{background:'rgba(255,255,255,.05)',padding:'20px',borderRadius:'20px'}}>Trade Value</div>
<div style={{background:'rgba(255,255,255,.05)',padding:'20px',borderRadius:'20px'}}>Waiver Watch</div>
</div>
</div>
)}
