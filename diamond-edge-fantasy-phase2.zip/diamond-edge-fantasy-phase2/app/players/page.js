
'use client'
import {useEffect,useState} from 'react';
export default function Players(){
const [teams,setTeams]=useState([]);
useEffect(()=>{
fetch('https://statsapi.mlb.com/api/v1/teams')
.then(r=>r.json())
.then(d=>setTeams(d.teams))
},[])
return(
<div style={{padding:'40px'}}>
<h1>MLB Database</h1>
{teams.map(t=><div key={t.id}>{t.name}</div>)}
</div>
)}
