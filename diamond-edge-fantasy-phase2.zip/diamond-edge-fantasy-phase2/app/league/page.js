
'use client'
export default function League(){
return(
<div style={{padding:'40px'}}>
<h1>League Setup</h1>
<select><option>ESPN</option><option>Yahoo</option></select>
<select><option>8</option><option>10</option><option>12</option></select>
<select><option>Points</option><option>Categories</option></select>
<button>Create League</button>
</div>
)}
