
export default function Login(){
return(
<div style={{padding:'40px'}}>
<h1>Login</h1>
<input placeholder='Email'/>
<input placeholder='Password' type='password'/>
<button>Login</button>
</div>
)}
